// ==UserScript==
// @name         BYPASS KING - Traffic Assistant
// @namespace    https://bypass-king.local/
// @version      1.0.0
// @description  GTraffic helper: page scan, OCR for user-selected images, link history, timer and code copy.
// @match        https://gtraffic.io/*
// @match        https://*.gtraffic.io/*
// @match        *://*/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_setClipboard
// @run-at       document-idle
// @require      https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js
// ==/UserScript==

(() => {
  'use strict';

  const STORE = {
    history: 'bk_history_v1',
    settings: 'bk_settings_v1',
    monitor: 'bk_monitor_enabled_v1',
    task: 'bk_task_keyword_v1'
  };
  const DEFAULTS = { seconds: 68, autoSave: true };
  const state = {
    settings: { ...DEFAULTS, ...(GM_getValue(STORE.settings, {}) || {}) },
    history: GM_getValue(STORE.history, []) || [],
    timerId: null,
    remaining: 68,
    detectedCode: '',
    monitorEnabled: !!GM_getValue(STORE.monitor, false),
    taskKeyword: GM_getValue(STORE.task, '') || ''
  };

  const css = `
    #bk-root{position:fixed;z-index:2147483647;right:8px;bottom:8px;width:min(300px,calc(100vw - 16px));max-height:72vh;overflow:auto;background:#101522;color:#f4f6fb;border:1px solid #344158;border-radius:12px;box-shadow:0 10px 30px #0008;font:12px/1.4 system-ui,sans-serif}
    #bk-root *{box-sizing:border-box}#bk-head{display:flex;align-items:center;justify-content:space-between;padding:8px 10px;background:#182237;border-radius:12px 12px 0 0;cursor:move}
    #bk-title{font-weight:900;font-size:14px;letter-spacing:.5px}#bk-title b{color:#f5c542}#bk-body{padding:9px;display:grid;gap:7px}
    #bk-root.bk-minimized{width:164px;max-height:none;overflow:hidden;border-radius:12px}
    #bk-root.bk-minimized #bk-head{border-radius:12px;padding:7px 9px}
    #bk-root.bk-minimized #bk-title{font-size:12px}
    #bk-root.bk-minimized #bk-head .bk-muted{display:none}
    .bk-row{display:flex;gap:7px;align-items:center}.bk-row>*{min-width:0;flex:1}
    .bk-section{font-weight:800;color:#c9d5eb;margin-bottom:4px}.bk-muted{color:#9ba9c0;font-size:11px}
    #bk-root input,#bk-root textarea{width:100%;background:#0c1220;color:#fff;border:1px solid #3b4961;border-radius:7px;padding:7px;font:inherit}
    #bk-root button{border:0;border-radius:7px;padding:7px 8px;background:#e6b936;color:#171717;font-weight:800;cursor:pointer}
    #bk-root button.secondary{background:#29364d;color:#eef3ff;border:1px solid #43516a}
    #bk-root button.danger{background:#6e2933;color:#fff}#bk-root button:disabled{opacity:.45;cursor:not-allowed}
    #bk-status{padding:9px;border-radius:8px;background:#1c2a40;color:#cfe1ff}
    #bk-history{display:grid;gap:5px;max-height:120px;overflow:auto}
    .bk-item{padding:7px;background:#192338;border-radius:7px;overflow-wrap:anywhere}
    .bk-item small{display:block;color:#9ba9c0;margin-top:3px}
    #bk-close{background:transparent;color:#cbd5e1;padding:2px 7px;font-size:18px}
    #bk-min{background:transparent;color:#cbd5e1;padding:2px 7px}
    #bk-root label{display:flex;align-items:center;gap:7px;color:#dce5f5}
    #bk-root input[type=checkbox]{width:auto}
    #bk-root input[type=file]{font-size:11px;padding:6px}
    #bk-root hr{border:0;border-top:1px solid #2b3850;width:100%}
  `;
  const style = document.createElement('style');
  style.textContent = css;
  document.documentElement.appendChild(style);

  const root = document.createElement('section');
  root.id = 'bk-root';
  root.innerHTML = `
    <header id="bk-head">
      <div><div id="bk-title">♛ <b>BYPASS</b> KING</div><div class="bk-muted">GTRAFFIC • TRAFFIC ASSISTANT</div></div>
      <div><button id="bk-min" title="Thu gọn">—</button><button id="bk-close" title="Đóng">×</button></div>
    </header>
    <div id="bk-body">
      <div id="bk-status">● Sẵn sàng • Đang theo dõi trang hiện tại</div>
      <div>
        <div class="bk-section">Nhiệm vụ / từ khóa phát hiện</div>
        <textarea id="bk-page-text" rows="3" placeholder="Nội dung trang sẽ được quét tại đây..." readonly></textarea>
        <div class="bk-row"><button id="bk-scan" class="secondary">Quét trang</button><button id="bk-copy-text" class="secondary">Copy nội dung</button></div>
      </div>
      <hr>
      <div>
        <div class="bk-section">Tự nhận diện nhiệm vụ</div>
        <input id="bk-keyword" type="text" placeholder="Từ khóa nhiệm vụ sẽ hiện ở đây">
        <div class="bk-row"><button id="bk-detect-task">Nhận diện NV</button><button id="bk-search-task" class="secondary">Mở Google</button></div>
        <label><input id="bk-monitor" type="checkbox"> Theo dõi mã ở trang đích</label>
        <div class="bk-muted">Chỉ đọc nội dung trang và tìm mã hiển thị; không tự click quảng cáo hoặc CAPTCHA.</div>
      </div>
      <hr>
      <div>
        <div class="bk-section">Đồng hồ lấy mã</div>
        <div class="bk-row"><input id="bk-seconds" type="number" min="1" max="3600" value="68" aria-label="Số giây"><button id="bk-start">Bắt đầu</button><button id="bk-reset" class="secondary">Đặt lại</button></div>
        <div id="bk-count" class="bk-muted">Cài đặt mặc định: 68 giây</div>
      </div>
      <hr>
      <div>
        <div class="bk-section">Link thủ công</div>
        <input id="bk-url" type="url" placeholder="https://...">
        <div class="bk-row"><button id="bk-open" class="secondary">Mở link</button><button id="bk-save">Lưu link</button></div>
        <label><input id="bk-autosave" type="checkbox" checked> Tự lưu link GTraffic hiện tại</label>
      </div>
      <hr>
      <div>
        <div class="bk-section">OCR ảnh nhiệm vụ</div>
        <input id="bk-image" type="file" accept="image/*">
        <button id="bk-ocr" class="secondary">Nhận diện chữ trong ảnh</button>
        <div id="bk-ocr-status" class="bk-muted">Chọn ảnh bạn muốn phân tích.</div>
      </div>
      <hr>
      <div>
        <div class="bk-section">Mã đã lấy xong</div>
        <input id="bk-code" type="text" placeholder="Dán mã hoặc quét mã hiển thị trên trang">
        <div class="bk-row"><button id="bk-copy-code">Copy mã</button><button id="bk-detect-code" class="secondary">Tìm mã trên trang</button></div>
      </div>
      <hr>
      <div>
        <div class="bk-row"><div class="bk-section">Lịch sử link</div><button id="bk-clear" class="danger">Xóa lịch sử</button></div>
        <div id="bk-history"></div>
      </div>
      <div class="bk-muted">Công cụ hỗ trợ đọc nội dung, ghi nhớ link và thao tác thủ công. Không tự vượt CAPTCHA, quảng cáo bắt buộc hoặc cơ chế bảo vệ của website.</div>
    </div>`;

  document.documentElement.appendChild(root);
  const $ = id => root.querySelector('#' + id);
  const setStatus = msg => { $('bk-status').textContent = msg; };
  const saveSettings = () => {
    state.settings.seconds = Math.max(1, Math.min(3600, Number($('bk-seconds').value) || 68));
    state.settings.autoSave = $('bk-autosave').checked;
    GM_setValue(STORE.settings, state.settings);
  };
  const saveHistory = () => GM_setValue(STORE.history, state.history.slice(0, 100));
  const addHistory = url => {
    if (!url || !/^https?:\/\//i.test(url)) return;
    state.history = [{ url, time: new Date().toLocaleString(), page: location.hostname },
      ...state.history.filter(x => x.url !== url)].slice(0, 100);
    saveHistory();
    renderHistory();
  };
  const renderHistory = () => {
    $('bk-history').innerHTML = '';
    if (!state.history.length) {
      $('bk-history').textContent = 'Chưa có link được lưu.';
      return;
    }
    state.history.forEach(item => {
      const div = document.createElement('div');
      div.className = 'bk-item';
      const link = document.createElement('div');
      link.textContent = item.url;
      const meta = document.createElement('small');
      meta.textContent = `${item.page || ''} • ${item.time || ''}`;
      const btn = document.createElement('button');
      btn.className = 'secondary';
      btn.textContent = 'Điền link';
      btn.addEventListener('click', () => { $('bk-url').value = item.url; });
      div.append(link, meta, btn);
      $('bk-history').appendChild(div);
    });
  };

  function scanPage() {
    const text = (document.body?.innerText || '').replace(/\n{3,}/g, '\n\n').slice(0, 12000);
    $('bk-page-text').value = text;
    const images = [...document.images].filter(img => img.width > 80 && img.height > 40).length;
    const videos = document.querySelectorAll('video').length;
    const links = [...document.links].filter(a => a.href && /^https?:/.test(a.href)).length;
    setStatus(`Đã quét trang • ${images} ảnh • ${videos} video • ${links} link`);
    return text;
  }

  function detectTaskKeyword() {
    const text = document.body?.innerText || '';
    const patterns = [
      /(?:google|tìm kiếm|search|gõ từ khóa|nhập từ khóa)[\s\S]{0,100}?["“']?([a-z0-9][a-z0-9 ._-]{1,40})["”']?/i,
      /(?:từ khóa|keyword)\s*[:：]\s*["“']?([^\\n"'“”]{2,60})/i
    ];
    for (const re of patterns) {
      const m = text.match(re);
      if (m && m[1]) {
        const keyword = m[1].trim().replace(/\s+/g, ' ');
        if (keyword.length >= 2 && keyword.length <= 60) {
          state.taskKeyword = keyword;
          GM_setValue(STORE.task, keyword);
          $('bk-keyword').value = keyword;
          setStatus('Đã nhận diện từ khóa nhiệm vụ: ' + keyword);
          return keyword;
        }
      }
    }
    setStatus('Chưa tự nhận diện được từ khóa. Hãy nhập thủ công.');
    return '';
  }

  function scanForVisibleCode() {
    const text = document.body?.innerText || '';
    const patterns = [
      /(?:verification|access|redeem|claim|gift)\s*code\s*[:：#-]?\s*([A-Z0-9-]{4,20})/i,
      /(?:mã\s*(?:xác nhận|nhận|quà|truy cập)?|code)\s*[:：#-]\s*([A-Z0-9-]{4,20})/i,
      /\b[A-Z0-9]{6,12}\b/g
    ];
    for (const re of patterns) {
      const m = text.match(re);
      if (m && m[1]) {
        $('bk-code').value = m[1];
        setStatus('Phát hiện chuỗi giống mã. Hãy kiểm tra rồi bấm Copy.');
        return m[1];
      }
    }
    return '';
  }

  function findCode() {
    const text = document.body?.innerText || '';
    const patterns = [
      /(?:your\s*)?(?:verification|access|redeem)\s*code\s*[:：]?\s*([A-Z0-9-]{4,16})/i,
      /(?:mã|code)\s*(?:xác nhận|nhận được)?\s*[:：]\s*([A-Z0-9-]{4,16})/i
    ];
    for (const re of patterns) {
      const match = text.match(re);
      if (match) {
        $('bk-code').value = match[1];
        setStatus('Đã tìm thấy chuỗi có dạng mã. Hãy kiểm tra trước khi sử dụng.');
        return match[1];
      }
    }
    setStatus('Chưa tìm thấy mã rõ ràng. Bạn có thể dán mã thủ công.');
    return '';
  }

  $('bk-scan').addEventListener('click', scanPage);
  $('bk-keyword').value = state.taskKeyword;
  $('bk-monitor').checked = state.monitorEnabled;
  $('bk-detect-task').addEventListener('click', detectTaskKeyword);
  $('bk-search-task').addEventListener('click', () => {
    const keyword = $('bk-keyword').value.trim();
    if (!keyword) return setStatus('Chưa có từ khóa. Hãy nhận diện hoặc nhập từ khóa trước.');
    state.taskKeyword = keyword;
    GM_setValue(STORE.task, keyword);
    GM_setValue(STORE.monitor, true);
    state.monitorEnabled = true;
    $('bk-monitor').checked = true;
    window.open('https://www.google.com/search?q=' + encodeURIComponent(keyword), '_blank', 'noopener');
    setStatus('Đã mở Google. Chọn kết quả phù hợp; BYPASS KING sẽ theo dõi mã trên trang đích.');
  });
  $('bk-monitor').addEventListener('change', () => {
    state.monitorEnabled = $('bk-monitor').checked;
    GM_setValue(STORE.monitor, state.monitorEnabled);
    setStatus(state.monitorEnabled ? 'Đã bật theo dõi mã trên trang này.' : 'Đã tắt theo dõi mã.');
    if (state.monitorEnabled) scanForVisibleCode();
  });
  $('bk-copy-text').addEventListener('click', () => {
    GM_setClipboard($('bk-page-text').value || '');
    setStatus('Đã copy nội dung quét.');
  });
  $('bk-seconds').value = state.settings.seconds;
  $('bk-autosave').checked = !!state.settings.autoSave;
  $('bk-seconds').addEventListener('change', saveSettings);
  $('bk-autosave').addEventListener('change', saveSettings);

  $('bk-start').addEventListener('click', () => {
    saveSettings();
    if (state.timerId) clearInterval(state.timerId);
    state.remaining = state.settings.seconds;
    $('bk-count').textContent = `Còn ${state.remaining} giây`;
    state.timerId = setInterval(() => {
      state.remaining--;
      $('bk-count').textContent = state.remaining > 0 ? `Còn ${state.remaining} giây` : 'Đã hết thời gian';
      if (state.remaining <= 0) {
        clearInterval(state.timerId);
        state.timerId = null;
        setStatus('Hết thời gian chờ. Kiểm tra trang và mã thủ công.');
      }
    }, 1000);
  });
  $('bk-reset').addEventListener('click', () => {
    if (state.timerId) clearInterval(state.timerId);
    state.timerId = null;
    state.remaining = state.settings.seconds;
    $('bk-count').textContent = `Đặt lại: ${state.remaining} giây`;
  });

  $('bk-open').addEventListener('click', () => {
    const url = $('bk-url').value.trim();
    try {
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error();
      window.open(parsed.href, '_blank', 'noopener');
    } catch { setStatus('URL không hợp lệ. Hãy nhập link bắt đầu bằng https://'); }
  });
  $('bk-save').addEventListener('click', () => {
    const url = $('bk-url').value.trim();
    try {
      const parsed = new URL(url);
      if (!['http:', 'https:'].includes(parsed.protocol)) throw new Error();
      addHistory(parsed.href);
      setStatus('Đã lưu link vào lịch sử.');
    } catch { setStatus('Link không hợp lệ.'); }
  });
  $('bk-copy-code').addEventListener('click', () => {
    const code = $('bk-code').value.trim();
    if (!code) return setStatus('Chưa có mã để copy.');
    GM_setClipboard(code);
    setStatus('Đã copy mã vào clipboard.');
  });
  $('bk-detect-code').addEventListener('click', findCode);
  $('bk-clear').addEventListener('click', () => {
    if (!confirm('Xóa toàn bộ lịch sử link đã lưu?')) return;
    state.history = [];
    saveHistory();
    renderHistory();
  });

  $('bk-ocr').addEventListener('click', async () => {
    const file = $('bk-image').files?.[0];
    if (!file) return $('bk-ocr-status').textContent = 'Hãy chọn một ảnh trước.';
    if (!window.Tesseract?.recognize) return $('bk-ocr-status').textContent = 'Không tải được thư viện OCR. Kiểm tra kết nối mạng.';
    $('bk-ocr').disabled = true;
    $('bk-ocr-status').textContent = 'Đang nhận diện ảnh...';
    try {
      const result = await window.Tesseract.recognize(file, 'eng+vie', {
        logger: m => {
          if (m.status) $('bk-ocr-status').textContent = `${m.status}${m.progress ? ` • ${Math.round(m.progress * 100)}%` : ''}`;
        }
      });
      const recognized = (result.data?.text || '').trim();
      $('bk-page-text').value = recognized;
      $('bk-ocr-status').textContent = recognized ? 'Nhận diện xong. Nội dung đã đưa vào ô kết quả.' : 'Không nhận diện được chữ trong ảnh.';
    } catch (err) {
      $('bk-ocr-status').textContent = 'OCR lỗi: ' + (err?.message || 'không xác định');
    } finally {
      $('bk-ocr').disabled = false;
    }
  });

  $('bk-min').addEventListener('click', () => {
    const body = $('bk-body');
    body.hidden = !body.hidden;
    root.classList.toggle('bk-minimized', body.hidden);
    $('bk-min').textContent = body.hidden ? '+' : '−';
    $('bk-min').title = body.hidden ? 'Mở rộng bảng' : 'Thu nhỏ bảng';
  });
  $('bk-close').addEventListener('click', () => root.remove());

  // Small drag handle so the panel can be moved away from page controls.
  let drag = null;
  $('bk-head').addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    const rect = root.getBoundingClientRect();
    drag = { x: e.clientX, y: e.clientY, left: rect.left, top: rect.top };
    $('bk-head').setPointerCapture?.(e.pointerId);
  });
  $('bk-head').addEventListener('pointermove', e => {
    if (!drag) return;
    root.style.left = `${Math.max(0, drag.left + e.clientX - drag.x)}px`;
    root.style.top = `${Math.max(0, drag.top + e.clientY - drag.y)}px`;
    root.style.right = 'auto';
    root.style.bottom = 'auto';
  });
  $('bk-head').addEventListener('pointerup', () => { drag = null; });

  const onGTraffic = location.hostname === 'gtraffic.io' || location.hostname.endsWith('.gtraffic.io');
  if (!onGTraffic && !state.monitorEnabled) {
    root.remove();
    return;
  }
  renderHistory();
  if (state.settings.autoSave && onGTraffic) addHistory(location.href);
  scanPage();
  if (!onGTraffic && state.monitorEnabled) {
    setStatus('Đang theo dõi trang đích để tìm mã hiển thị.');
    scanForVisibleCode();
  }

  // Observe page changes and refresh the visible text snapshot without clicking anything.
  let debounce;
  const observer = new MutationObserver(() => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      const text = (document.body?.innerText || '').slice(0, 12000);
      if (text && $('bk-page-text')) $('bk-page-text').value = text;
      if (state.monitorEnabled && !onGTraffic && !$('bk-code').value.trim()) scanForVisibleCode();
    }, 700);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
})();
